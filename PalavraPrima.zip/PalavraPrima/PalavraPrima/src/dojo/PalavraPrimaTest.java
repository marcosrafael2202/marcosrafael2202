package dojo;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Coding Dojo utilizando o problema Palavras-Primas
 * 
 * Fonte: Marianna Reis. Palavras Primas. DojoPuzzles.com 
 * [http://dojopuzzles.com/problemas/exibe/palavras-primas/]
 * 
 */
public class PalavraPrimaTest {

	
	@Test
	public void testNome() {
		int valor = PalavraPrima.converteEmNumero("Maria");
		assertEquals(39+1+18+9+1, valor);
	}

	@Test
	public void testPalavraComidaEhPrima() {
		boolean resultadoTeste = PalavraPrima.ehPalavraPrima("Comida");//29+15+13+9+4+1 = 71 que � primo
		assertEquals(true, resultadoTeste);
	}

	@Test
	public void testPalavraBolaEhPrima() {
		boolean resultadoTeste = PalavraPrima.ehPalavraPrima("Bola");//28+15+12+1= 56 que n�o � primo
		assertEquals(false, resultadoTeste);
	}

	@Test
	public void testPalavraAMinusculoEhPrima() {
		boolean resultadoTeste = PalavraPrima.ehPalavraPrima("a");
		assertEquals(false, resultadoTeste);
	}

	@Test
	public void testPalavraEMinusculoEhPrima() {
		boolean resultadoTeste = PalavraPrima.ehPalavraPrima("e");
		assertEquals(true, resultadoTeste);
	}

}
