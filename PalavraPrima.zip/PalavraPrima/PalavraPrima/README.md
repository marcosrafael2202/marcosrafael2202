# Palavra-Prima
Prática de Coding Dojo realizada com a turma de 4o. ano do Técnico em Informática para Internet Integrado ao Ensino Médio do IFPR - Campus Telêmaco Borba.

Problema utlizado: Palavras-Primas (Marianna Reis. Palavras Primas. DojoPuzzles.com 
[http://dojopuzzles.com/problemas/exibe/palavras-primas/])
